package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
    }

    public void onCheck1(View view){

        TextView view23 = findViewById(R.id.view23);
            view23.setText("Wrong");

    }

    public void onCheck2(View view){
        TextView view23 = findViewById(R.id.view23);
        view23.setText("Wrong");

    }

    public void onCheck3(View view){

        TextView view23 = findViewById(R.id.view23);
        view23.setText("Correct!!");


    }

}