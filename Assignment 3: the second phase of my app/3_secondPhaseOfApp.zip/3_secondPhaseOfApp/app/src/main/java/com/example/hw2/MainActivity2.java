package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void OnClickBtn1(View view){
        EditText location = findViewById(R.id.edit1);
        EditText from = findViewById(R.id.edit2);
        EditText likeToBe = findViewById(R.id.edit3);
        EditText family = findViewById(R.id.edit4);
        EditText food = findViewById(R.id.edit5);

        TextView view1 = findViewById(R.id.view1);
        TextView view2 = findViewById(R.id.view2);
        TextView view3 = findViewById(R.id.view3);
        TextView view4 = findViewById(R.id.view4);
        TextView view5 = findViewById(R.id.view5);

        view1.setText("My location: " + location.getText().toString());
        view2.setText("I am from " + from.getText().toString());
        view3.setText("I want to be " + likeToBe.getText().toString());
        view4.setText("My family is from " + family.getText().toString());
        view5.setText("My favorite food is " + food.getText().toString());

    }

    public void OnClickBtn2 (View view){

        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);

    }
}