package com.example.hw2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void OnClickBtn (View view){

        TextView firstName = findViewById(R.id.txtFirst);
        TextView lastName = findViewById(R.id.txtLast);
        TextView emailAdd = findViewById(R.id.txtEmail);

        EditText first = findViewById(R.id.edtFirst);
        EditText last = findViewById(R.id.edtLast);
        EditText email = findViewById(R.id.edtEmail);

        firstName.setText("First Name: " + first.getText().toString());
        lastName.setText("Last Name: " + last.getText().toString());
        emailAdd.setText("Email: " + email.getText().toString());


    }
}